FastWay - Worldwide Product Discovery Platform
==========================================

Built by Meta AI - Original design inspired by Amazon Canada & Walmart Canada (not a clone)

WHAT THIS IS:
Worldwide product search and comparison engine.
Search any product -> finds matching products from multiple retailers/countries -> compare -> click through to retailer.

FEATURES:
- Homepage with large search bar: "Search the world's products in one place"
- Country selector: Canada, US, UK, Germany, Japan, Australia, France
- Currency selector: CAD, USD, GBP, EUR, JPY, AUD with auto conversion
- Product cards: real matching photos, title, retailer logo, country flag, price + original + discount, rating + reviews, shipping, availability, View Product
- Price comparison grouping: same product across retailers (Amazon Canada $1599, Walmart $1579, Best Buy $1599, Amazon US $1099 etc)
- Filters: Category, Brand, Price, Currency, Country, Retailer, Rating, Shipping, Discount, Color, Size, Specs
- Sorting: Relevance, Lowest/Highest price, Rating, Most reviews, Biggest discount, Newest
- Product page: gallery, specs, price comparison, similar products, View at Retailer button (with ?tag=fastwayca-20)
- Clean footer - no raw retailer dump, no system diagram
- No Temu, no DHgate - only trusted official retailers
- 150+ mock products from Amazon, Walmart, Best Buy, eBay, Costco, Target, Home Depot, etc.
- Fully responsive (desktop, tablet, mobile)
- Architecture: Retailer abstraction, ProductSource (AmazonSource, WalmartSource, BestBuySource, etc), ready for real APIs

RETAILER LINKS USED:
- Amazon Canada https://www.amazon.ca/
- Amazon US https://www.amazon.com/
- Walmart Canada https://www.walmart.ca/fr and https://www.walmart.ca/en
- Walmart US https://www.walmart.com/
- Best Buy Canada https://www.bestbuy.ca/
- Best Buy US https://www.bestbuy.com/
- eBay https://www.ebay.ca/ / https://www.ebay.com/
- Costco https://www.costco.ca/ / https://www.costco.com/
- Target https://www.target.com/
- Home Depot https://www.homedepot.ca/ / https://www.homedepot.com/
- Canadian Tire https://www.canadiantire.ca/
- London Drugs https://www.londondrugs.com/

HOW TO DEPLOY:
1. This folder contains index.html (single file app)
2. Drag & drop the folder onto Vercel.com (https://vercel.com/new) or Netlify
3. Your site will be live at https://your-project.vercel.app
4. For custom domain, add it in Vercel dashboard

AFFILIATE:
Add your Amazon tag ?tag=fastwayca-20 to Amazon productUrl for commission.
Disclosure: As an Amazon Associate we earn from qualifying purchases.

LIVE DEMO (old version):
https://fastway-three.vercel.app

Built: 2026
